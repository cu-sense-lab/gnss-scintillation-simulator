double gam_outer_r(double r, double y0);
double gam_outer(double eta, double mu, double mu_outer);
double gam_new(double eta, double mu, 
               double U1, double U2, double p1, double p2, double mu0, double mu_outer, double mu_inner, int debug,
               double *err_, long *nfunc_);
