
double gam_analytic(double p, double eta, double mu);

